﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statistics5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String[] values = textBox1.Text.Split(",");
            List<double> doublevalue = new List<double>();
            foreach(String s in values)
            {
                doublevalue.Add(double.Parse(s));
            }
            double range = doublevalue.Max() - doublevalue.Min();
            MessageBox.Show("Range " + range);
            doublevalue.Sort();
            int index = doublevalue.IndexOf(double.Parse(textBox2.Text));
            double percentile = (double.Parse(index.ToString()) / double.Parse(doublevalue.Count.ToString()) * 100);
            MessageBox.Show("Percentile " + percentile);
        }
    }
}
